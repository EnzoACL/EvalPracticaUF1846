
function Avatar({url , info}) {
    
        return (
            <>
                <img src={url} alt={info}/>  
            </>
    )
    
}

export default Avatar