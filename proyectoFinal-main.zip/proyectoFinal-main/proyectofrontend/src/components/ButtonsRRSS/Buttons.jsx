
function Buttons() {
    return (
        <>
            <input type="button" value="Like" />            
            <input type="button" value="Comentar" />            
            <input type="button" value="Compartir" />
        </>
    )
}

export default Buttons